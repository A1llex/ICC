 
Fernandez Aguilar Alex Gerardo  314338097

lo entregue tarde porque no pude solucionar mis dudas hasta en clase y con la nueva informacion de la practica