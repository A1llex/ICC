Fernandez Aguilar Alex Gerardo  314338097


1-para estar seguro de que no sea la unica cadena que lo contiene seria recorrer toda lista ligada hasta el final e irlo sumando en una variable que se imprimira al final de esta
